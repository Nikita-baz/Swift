//
//  ViewController.swift
//  Meditation
//
//  Created by Student on 30.11.2021.
//

import UIKit
import Alamofire
import SwiftyJSON

class SingInViewController: UIViewController {

    @IBOutlet weak var inputPassword: UITextField!
    @IBAction func signInAction(_ sender: UIButton) {
    }
}

