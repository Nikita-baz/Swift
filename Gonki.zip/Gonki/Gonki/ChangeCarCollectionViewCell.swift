//
//  ChangeCarCollectionViewCell.swift
//  Gonki
//
//  Created by user on 18.10.2021.
//

import UIKit

class ChangeCarCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var carPicture: UIImageView!

    
}
