//
//  ViewController.swift
//  Bazarov-Kuznetsov_2
//
//  Created by user on 23.09.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

